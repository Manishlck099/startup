let jat= ["manish","yogesh","deepak"]
console.log(jat.length-1)//this will give you the index of an 
console.log(jat[jat.length-1])//this will give us the last index value