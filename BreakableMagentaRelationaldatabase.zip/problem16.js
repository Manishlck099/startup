let supermarket= "closeup";
if(supermarket=="colgate"){console.log("please give me colgate")}
else if(supermarket=="pepsodent"){console.log("please give me pepsodent")}
else{console.log("mom i didnt find")}