let a= 10
let b= 20
if (a>b){console.loG("a is greater")}
         else{console.log("b is greater")}

let name= "manish"
let name1= "manisha"
if(name==name1){console.log("names are same")}
else{console.log("names are not same")}

let item_price= 1000;
let money_you_have= 500;
if(money_you_have>=item_price){console.log("i have enough money")}
else{console.log("i dont have enough money")}