let jaat= ["manish","yogesh","gaurav"]
console.log(jaat[1]);