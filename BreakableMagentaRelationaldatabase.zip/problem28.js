//this username and passwored stored in system
let stored_username= "pagal"
let stored_password= "intelligent"
//while i login through
let username= "pagal"
let password= "intelligent"
//time to print

if(stored_username==username){console.log("able to login through same login through same username")}
if(stored_password==password){console.log("and passsword")}
else{console.login("bhagvan malik")}