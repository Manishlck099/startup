let name= "masai school"

let name2= "A transformation in education"

console.log(name,name2)