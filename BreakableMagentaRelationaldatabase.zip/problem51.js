let i=10;
while(i>=1){
  if(i%2==1){
    console.log(i)
  }
  i--;
}