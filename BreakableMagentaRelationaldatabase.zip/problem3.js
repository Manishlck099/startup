var name= "manish chaudhary"
var age= 22;

console.log(typeof(name))
console.log(typeof(age))