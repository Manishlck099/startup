let sum=0
for(let i=1; i<=10; i++){
   (3*i=i)
    i%5==0
    sum=sum+i
  
}
  console.log(sum);