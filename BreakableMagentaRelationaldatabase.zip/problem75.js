let bag=""
for(let i=1; i<=10; i++){
  bag=bag+"*"
}
console.log(bag)
