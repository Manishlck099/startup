let person_age= 22;
let legal_driving_age= 18;

if(person_age<legal_driving_age){console.log("person is not able to drive")}
  else if(person_age>=legal_driving_age){console.log("person is able to get a licence")}
else{console.log("person is default")}