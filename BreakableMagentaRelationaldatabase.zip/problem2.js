let name= "manish chaudhary"
console.log(name)

let name1= 'manoj kumar'
console.log(name1)

let name2= "mamta devi"
console.log(name2)