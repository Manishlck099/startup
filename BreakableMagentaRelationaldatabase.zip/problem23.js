let hostage= 21;
switch(hostage){
  case 23: console.log("murderer");
  break;
  case 21: console.log("sex and the city")
    break;
  default:console.log("wrong data")
    
    
}