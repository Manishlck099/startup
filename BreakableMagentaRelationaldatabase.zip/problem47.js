let x= ""
  for (let i=1; i<=10; i++){
  x=x+i+"*"
  }
console.log(x);