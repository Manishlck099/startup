let a= 23;
let b=a++;
console.log(b);
console.log(a);

let c= 26;
let d= ++b;
console.log(b);
console.log(a);