let number= 0;
while(number<=100){
  if(number%3==0){
    console.log(number)
  }
  number++;
}