let arr= "manish  jaat boy"
let space=0;
for (let i=0; i<arr.length; i++){
  if(arr[i]==" "){
    space++
  }
}
console.log("words",space+1)