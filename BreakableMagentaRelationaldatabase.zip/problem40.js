let i=1
while(i<=20){
console.log("kanishka i love you very much i cant live without you")
i++;}