let a= [1,-1,-2,-3,6,0];

a[1]=0;
a[2]=0;
a[3]=0;

console.log(a);