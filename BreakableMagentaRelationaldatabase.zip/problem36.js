let day= "sun"
switch(day){
  case "mon":console.log("monday");
    break;
  case "tue" : console.log("tuesday");
    break;
  case "wed" : console.log("wednesday");
    break;
  case "thru" : console.log("thrusday");
    break;
  case "fri" : console.log("friday");
    break;
  case "sat" : console.log("saturday");
    break;
  case "sun" : console.log("sunday");
    break;
}