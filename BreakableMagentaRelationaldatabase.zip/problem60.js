let jat=["manish","yogesh","gaurav"];
for(let i= 0; i<=2; i++){
  console.log(i+1,jat[i]);
}
  