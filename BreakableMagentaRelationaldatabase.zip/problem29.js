let age= 22;
switch(age){

  case age>=13 || age>=19:
    console.log("passed teenage");
    break;
  case age>=20 || age<=29:
    console.log("currently in twenties");
    break;
  default:
  console.log("nullaa");   }
