let number= 10
while(number<=50){
  if(number%2==1){
    console.log(number);
  }
  number++;
}