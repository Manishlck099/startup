       console.log(`𝗥𝗲𝘀𝘂𝗹𝘁`)
const name="NAME-🇲🇦🇳🇮🇸🇭"
const school= "SCHOOL-🅗🅐🅡🅘 🅥🅐🅡🅓🅘"
console.log(name,school)

let section= "section-🅐"
let rollno= "rollno-𝟚𝟞"
console.log(section,rollno)

let grades= "CGPA-7.4"
console.log(grades)
console.log("english","maths","science")
console.log(100.000 ,  100.000  , 100.000);