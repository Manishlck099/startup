var i= 1;
while (i<5);{
console.log("hello world");
  i++;
}