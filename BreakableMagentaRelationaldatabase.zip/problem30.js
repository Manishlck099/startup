let age=22;

if(age>=13 && age>=19){
  console.log("teenage")
}
else if(age>=20 && age<=29){
  console.log("in twenties")
}
else{
  console.log("no data")
}