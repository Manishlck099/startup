let eligible_driving_age= 18;
if(eligible_driving_age="driving license 21"){console.log("print driving license")}
else{console.log("NA")}