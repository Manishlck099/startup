let a= "manish"
console.log(a.length)


let b= `royal jaat never give up`
console.log(b[17])

let c= `jaat on the way`
for (let i=0; i<c.length; i++)
  console.log(c[i])