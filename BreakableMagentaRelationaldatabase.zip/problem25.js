let number= 30;
if(30%"3"){console.log("30 is a multiple of three")}
  else if(30/"3"){console.log("30 is a pure multiple of three")}
  
else{console.log("30 is not a multiple of three")}