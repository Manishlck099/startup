for(let day=1; day<=10; day++){
  console.log("i used to visit Dilsdad garden in search of my love for day" ,day)


  let x=""
  for(let seed=1; seed<=2; seed++)
    x=x+seed+"   "
  console.log("but i never find her in gali", x,)
}