for(let love=1; love<=10; love++){
  console.log("i love you for", love)

  for(let kanishka=1; kanishka<=love; kanishka++)
    console.log("kanishka", kanishka)
}