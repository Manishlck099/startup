let jat= ["manish","yogesh","deepak"];



let jat2= ["anju","preeti"];


let jat3= [...jat,...jat2];//add two array
console.log(jat3);