let a= 10;
let b= 20;
console.log(((a+b)>(b-a))<=((b/a)>(a%b)));