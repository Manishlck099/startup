let number= 4;
console.log(number*3+7-10);