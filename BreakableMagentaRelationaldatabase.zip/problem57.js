let jat= ["manish","gaurav"]

jat.pop();// to remove last array
console.log(jat);