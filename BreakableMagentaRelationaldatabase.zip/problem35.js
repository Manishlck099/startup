let name= "goku"
let name2= "luffy"
let name3= "gon"
if(name==name2==name3){console.log("all the names are same")}
  else if(name==name2){console.log("name is equal to name2")}
    else if(name2==name3){console.log("name2 is equal to name3")}
      else if(name3==name){console.log("name3 is equal to name")}
else{console.log("different")}





