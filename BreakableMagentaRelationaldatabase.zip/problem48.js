for(let i=1; i<=2000; i++){
  if(i==20){
    break;
  }

console.log(i)
}