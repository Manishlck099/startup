for(let i=1; i<=40; i++){
  if(i==25){
    continue;
  }
  console.log(i);
}