let supermarket= "dabur"
if((supermarket=="colgate")||(supermarket=="pepsodent")||(supermarket=="dabur")){console.log("i buyed")}
