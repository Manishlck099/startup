let a=10;
for(let i=1; i<=15; i++){
  i=a-i
  a=a+i
}
console.log(a)
