let arr=["tune","mere","jana","kabhi","nhi","jana","ishq","mera","dard","mera"]
let character= 0;
for(let i=0; i<arr.length; i++){
  character=character+arr[i].length
}
  
  console.log(character)
  