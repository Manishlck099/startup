let mobile= "samsang"
let mobile1= "iphone"
let ram="4gb"
let mah="5000"
if(mobile="samsung"){console.log()}