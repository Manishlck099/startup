for(let i=1; i<=3; i++){
console.log( "farm",i)
 let bag=""
  for(let k=1; k<=5; k++){
  bag=bag+"*"}
    console.log(bag)
  

}
