let arr = [1,5,-546,4,-43,343]

let min= +Infinity
let max= -Infinity
for(let i=0; i<arr.length; i++){

  if(arr[i]<min)
  arr[i]=min

 else if(arr[i]>max)
  arr[i]=max
}
console.log(max,min)