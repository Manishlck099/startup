

let bag= ""
for(let jat=1; jat<=9; jat++){
   bag= bag+"*"}
  console.log(bag);
