let jaat= ["manish","yogesh","deepak"]
console.log(jaat);