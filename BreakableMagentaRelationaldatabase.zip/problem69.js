for(let day=1; day<8; day++){
  console.log("student goes to school",day)
  for(classes=1; classes<8; classes++)
    console.log("classes",classes)
}