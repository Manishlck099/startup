let number= 0;
while(number<=10){
  console.log(number);
  number++;
}