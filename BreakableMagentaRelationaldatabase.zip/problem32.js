//let albhabet= a, e, i, o, u

let albhabet= "u";
if((albhabet="a") || (albhabet="e") || (albhabet="i") || (albhabet="o") || (alphabet="u")){console.log("a number is a vowel")}
else{console.log("a number is a constant")}
