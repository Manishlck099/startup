let jat= ["manish","deepak","gaurav"];



jat[1]="yogesh"
jat[2]="babbul"


console.log(jat);