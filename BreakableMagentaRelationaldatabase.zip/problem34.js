let number=222;
let number2= 324;
let number3= 456;
if((number>number2)&&(number>number3)){console.log("number1 is greatest")}
else if((number2>number)   &&    (number2>number3))      {console.log("number 2 is greatest")}     
   else if((number3>number) && (number3>number2)){console.log("number3 is greater")}
else{console.log("some technical glitch")}