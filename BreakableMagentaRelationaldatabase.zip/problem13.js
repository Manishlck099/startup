let a= 2;
let b= 3;
if(a>b){console.log("a is grater than b")}
 else{console.log("b is greater than a")}