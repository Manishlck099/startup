let jaat= ["manish", "yogesh", "deepak"]
for(let i=0; i<jaat.length; i++){
  console.log(jaat[i]);
}