let albhabet= "c"
if((albhabet=="a") || (albhabet=="e") || (albhabet=="i") || (albhabet=="o") || (albhabet=="u")){console.log("a albhabet is a vowel")}
else{console.log("an albhabet is a constant")}