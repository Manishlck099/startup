let number= 5;
while(number>=1){
  console.log(number);
  number=number-2
    ;
  
}
