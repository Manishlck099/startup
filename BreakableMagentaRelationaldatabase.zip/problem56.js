let jaat=["manish", "gaurav", "yogesh"]
console.log(jaat);
jaat.push("deepak")//it is used to add element in array
console.log(jaat);