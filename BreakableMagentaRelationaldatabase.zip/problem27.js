let a= 30;
let b= 45;

if(a>b){console.log("means i am zero")}
else if(b>=a){console.log("mean i am hero")}
  else if(b==a){console.log("i am genius")}
else{console.log("i am nobody")}