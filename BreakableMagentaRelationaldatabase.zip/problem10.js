
console.log(3<2);
console.log(34785839<=675758755);
console.log(344>=544);
console.log("a"=="a")
console.log(3=="3")
let a= 15;
let b= 15;
let c= "15"
console.log(a+b+c)
console.log("hundred"<7)