let light= "red"
let light2= "yellow"
let light3= "green"
let light4= "error"

if(light=="yellow"){console.log("we have to wait")
}
else if(light2=="red"){console.log("we have to stop")
}
else if (light3=="green"){console.log("we have to drive")
}
else{console.log("do whatever you want")}