let A= 95
let B= 75

console.log(A+B);
console.log(A*B);