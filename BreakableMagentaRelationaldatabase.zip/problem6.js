console.log(15%4)

console.log(17*99999);
let jaat_is_jaat= "manish_chaudhary_is_hero"
console.log(jaat_is_jaat)
let a= 3;
let b=2;
console.log(a-b);
console.log(25**.5)
let e= "goku"
let f= "sunio"
console.log(typeof(e+f))
let y="jaat"
let z=10;
console.log(typeof(y+z))
console.log(y+z)