let aman_marks= 75;
let total_marks= 150;
console.log("aman score"+aman_marks+ "out of"+total_marks)

let name= "masai"
console.log(name)

let x= 12;
let y= "12"
console.log(x+y);