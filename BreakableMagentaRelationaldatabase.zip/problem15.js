if(100>5){console.log("100 is bigger than 5")}
if("luffy===luffy"){console.log("luffy is same")}