let a= 7;
let b= 8;
console.log((a==b)||(b>a)||(a>b))